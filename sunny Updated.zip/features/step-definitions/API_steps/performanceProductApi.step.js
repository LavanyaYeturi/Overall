const { When, Then } = require('@wdio/cucumber-framework');
const productsPage = require('../../pageobjects/performanceProductApi.js');

let maxParallelCalls;

When('I repeatedly invoke the products API endpoint with increasing parallel calls', async function () {
    maxParallelCalls = 1;
    let isSuccess = true;

    while (isSuccess) {
        isSuccess = await productsPage.invokeProductsAPIParallelCalls(maxParallelCalls);
        if (isSuccess) {
            console.log(`All ${maxParallelCalls} parallel calls succeeded.`);
            maxParallelCalls++;
        } else {
            console.log(`Parallel calls failed at ${maxParallelCalls}.`);
        }
    }

    maxParallelCalls--; // Last successful count
});

Then('I should determine the maximum parallel calls before failures occur', function () {
    console.log(`Maximum parallel calls before failures occur: ${maxParallelCalls}`);
});
