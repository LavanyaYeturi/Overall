const {exec} = require('child_process');
const {promisify} = require('util');
const execAsync = promisify(exec);
const fs = require('fs');
const path = require('path');

const folderPath = `${process.cwd()}/net8.0/tmp`;

class commandPrompt{
    // async runCommand(command1, directory1){
    //     try{
    //         const{stdout, stderr} = await execAsync(command1, {cwd: directory1});
    //         if(stderr){
    //             console.error("hello")
    //         }
    //     }
    // }
}
 


