const axios = require("axios");
let retailApiData = require('../../data/retailApiData.json');
let dataFeedApiData = require('../../data/dataFeedApi.json')
class ProductsPage {
    async invokeProductsAPIParallelCalls(callCount) {
        console.log("######################################",callCount)
        const url = 'https://retail-api.qa.sunnyrewards.com/api/v1/products';
        const requests = [];
         for (let i = 1; i <= callCount; i++) {
            requests.push(browser.call(() => axios.post(url, retailApiData.productsApiPayload, {
                headers: {
                    'X-API-Key': dataFeedApiData.x_api_key,
                    'Content-Type': 'application/json'
                }
            })));
            }
            try{
            const responses = await Promise.all(requests);
            console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@",responses[0].status)
            return responses.every(response => response.status === 200);
            }catch(error){
                return false;
            }
    }
}

module.exports = new ProductsPage();
