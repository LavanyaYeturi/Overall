const DatabaseConsts = {
  username: "happusr",
  host: "heliosdevdb.cd9buezfisvm.us-east-2.rds.amazonaws.com",
  host_qa : "localhost",
  psd: "negKIOKktUR@yk2Q",
  port: 8432,
  dbName: "helios",
  dbName_qa : "helios-qa-db"
};

exports.Const = DatabaseConsts;
