const { When, Then } = require("@wdio/cucumber-framework");
const database = require("../../pageobjects/api/databaseConnection");
const utilTools = require("../../../utils/tools");
require("dotenv").config();
const bffApiData = require("../../../data/bffApiData.json");
const { expect, assert, Assertion } = require("chai");
const utilConst = require("../../../utils/const");
const { Client } = require('pg');

Then(/^User validate consumer balance amount from wallet_transaction table$/, async() => {
    await database.connectToPostgres();   
})

Then(/^User validate consumer balance amount from wallet_transaction table when prize out fail$/, async() => {
    await database.dbConnectRedemption_Fail();   
})

Then(/^User verifies enroll task API response with the db data from cosumer_task table$/, async () => {
    await database.dbConnect_consumerTaskTable();
  })
  
  